#include <stdio.h>

#include "main.h"

int main(int argc, char *argv[])
{
    printf("--------------------------------- PART III ------------------------------\n");
    func_cache();
    printf("---------------------------------- PART IV ------------------------------\n");
    func_swap_endian();
    printf("----------------------------------- PART V ------------------------------\n");
    func_shift_endian();
    return 0;
}
