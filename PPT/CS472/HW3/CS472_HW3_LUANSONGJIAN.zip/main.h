#ifndef _MAIN_H_
#define _MAIN_H_

#define KILOBYTE 1024
#define MEGABYTE 1024 * 1024
#define STEP 8 * MEGABYTE
#define ARRAY_SIZE 16 * MEGABYTE

void func_cache();
void func_swap_endian();
void func_shift_endian();

#endif
